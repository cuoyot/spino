# Spino Sightreader Game

Independent gameplay prototype derived from Spino's casual mobile practice concept. The piano synthesizer in `src/audio.js` was copied from the current Spino source on 2026-10-07. The notebook application and its data are untouched. This project has its own `spino-game-best` browser storage key.

Run `npm run dev` and open http://127.0.0.1:5174. Run `npm test` for deterministic gameplay checks. No dependencies or install step are required with Node 22.

## First gameplay proposal

- Notes travel right to left toward a fixed play line. Match the exact MIDI pitch at arrival, using touch, computer keyboard or a connected MIDI piano.
- Three lives; wrong pitches, early presses and missed notes each consume one target and one life. A failed target cannot charge twice. Holding note durations is not scored yet.
- Level 1: whole notes C4 E4 G4, 48 BPM, ±700 ms. Every eight correct notes promotes a level, adds 8 BPM and reduces the window by 70 ms (caps: 120 BPM and ±110 ms).
- Level 2 introduces D and F; level 3 uses half notes; level 4 expands to the C4–C5 octave; level 5 uses quarter notes; level 6 introduces sharps. No bass clef or chords yet.
- Each level gives a new 3.5 second lead-in. The shaded play zone reflects the actual timing tolerance. Later levels remove note-name hints.
- Score: 100 per hit plus up to 100 timing points and up to 50 streak points. Perfect hits within ±60 ms (or 30% of the window if smaller) earn an additional 150 points and a gold burst. Best score stays on this browser. Rewards and full home-page design remain for the next phase.
- Pause freezes the game clock. Switching away automatically pauses. Resume does not penalize time spent paused.

These tuning values are implemented proposals pending playtesting. Browser review is not native Android acceptance. No APK has been built.

Streak rewards: every 10 consecutive hits adds 250 points; every 20 restores one lost life (maximum three). Mistakes reset the streak and recharge meter. Level changes preserve the streak.

Home options: Easy starts at level 1 (48 BPM, whole notes), Medium at level 3 (64 BPM, half notes), Hard at level 5 (80 BPM, quarter notes), Expert at level 6 (88 BPM, quarter notes with sharps). Progression adds levels from that starting point. English is the default; Spanish uses Do/Re/Mi/Fa/Sol/La/Si note names throughout the keyboard and score hints. Language and starting difficulty are remembered in separate browser settings.

Musical phrases: after four random notes (once pitches allow), a familiar melody appears; subsequent phrases are separated by 12 random notes. Short C-major arrangements of Mary Had a Little Lamb, Ode to Joy and Twinkle, Twinkle, Little Star preserve repeated notes and longer endings. Whole-note beginner arrangements use uniform durations. A phrase keeps its tempo and timing tolerance across level changes. Level promotion now preserves queued notes without clearing the score or adding another countdown. Audio follows the written spacing with capped sustain; no prerecorded tune or automatic answers are added.

Audio: 13 locally bundled FluidR3 acoustic grand piano samples cover C4–C5, with a short release tail. Samples preload; synthesizer playback remains available when loading fails or for pitches outside the sample range. Attribution is shown on the home page; see assets/piano/NOTICE.md.
Additional phrases: Frère Jacques, London Bridge, Happy Birthday (includes B-flat, so appears once accidentals are available), and an original tarantella-style dance motif. Written durations are capped at whole notes for the current renderer.

Harmonic continuity: random interludes are replaced by four-note bridges chosen through tonic–subdominant–dominant–tonic chord tones in the incoming phrase key (C major, F major for Happy Birthday, A minor for the dance). Voice leading minimizes leaps from the previous melody endpoint and into the next opening note. Bridges retain the departing tempo; incoming phrases increase by at most 8 BPM. The initial reading motif uses C-major chord tones. Existing phrase melodies remain unchanged.

Life recharge now allows three normal hearts plus three gold hearts. Gold hearts absorb two mistakes each, are spent first, and appear cracked after their first hit. Recharge first restores missing normal hearts, then adds gold hearts; if the active gold heart is cracked it repairs that heart first. Maximum protection is nine mistakes (three normal plus six gold charges).

Note-name assistance: each exact pitch displays its localized name on its first five appearances in each run, at all difficulty levels. Later occurrences hide the hint. Counts include generated notes in the continuous queue and reset on a new run; mistakes do not extend the five-appearance allowance.

Played note duration now equals written beats × 60 / the note’s phrase BPM, triggered by a single press. The old 85% shortening and 2.5-second cap are removed. Long sampled notes use a crossfaded sustain loop; the release fade occurs inside the written duration and playback stops at its endpoint.

Gentler progression (2026-10-07): promotion now requires 24 correct notes. Starting tempos are 48/60/72/76 BPM for Easy/Medium/Hard/Expert, then +2 BPM per level above Expert, capped at 96 BPM. Timing tolerance decreases by 20 ms per level from ±700 ms, with a generous ±320 ms floor. On levels 5+, every two tunes are followed by a four-beat rest; a visible countdown marks the rest, inputs during it are ignored, and streaks/lives are preserved.

Design review 2026-10-07: bright lavender-and-paper interface with original vector mascot artwork, black ink notation on warm white, enlarged mobile score, visible streak counter and animated reward flights. Catalan joins English/Spanish including note names, melodies and operational copy. MIDI controls removed. End-run is only in the pause menu; browser back opens pause and preserves the run. Android browser back uses the same history behavior; native Android activity acceptance remains unverified (no APK built). Timing now uses an early window of 1.25 × the base tolerance and a late window of 0.65 × it, with scoring normalized to the applicable side. New evidence is saved separately in evidence/2026-10-07-design-01.

Accepted style: Clean Arcade, with dark plum surfaces, coral actions, gold streak rewards and subtle drifting notes/stars/circles behind opaque gameplay surfaces. Background motion pauses with the game and is disabled for reduced motion. In short landscape viewports, score/lives/pause/streak move beside the score and the keyboard occupies 38% of viewport height. Pause uses a drawn two-bar symbol plus localized text. The header flag picker shows only the selected language until opened, supports keyboard focus/Escape/outside click, and persists English/Spanish/Catalan selection. Review evidence: evidence/2026-10-07-arcade-01 (responsive browser).

Android review build: Spino Arcade 0.1.0, package com.miguecoll.spino.sightreadergame, independent from Spino. Build with npm run apk using the existing portable Android/JDK toolchain. Credits and release notes are accessed at the end of How to play. Clef changes begin at level 5+, only after every four completed phrases and at least 45 seconds apart: a 4.5-second announced pause, then 2.5 seconds of preview before the next note. Bass phrases transpose down one octave to C3–C4, with corresponding keyboard and piano samples. Every change resets the five-appearance name hint counters, including return to treble.

Audio adjustment: sound is capped at two beats (a half note) at the phrase tempo, while written durations and note spacing remain unchanged. Playback uses the unmodified natural piano sample; sustain looping and its crossfade are removed to avoid artificial sounding long tones.

Learning protection: notes 1–20 charge a heart hit per four mistakes, 21–40 per three, 41–60 per two, then per mistake. Attempted notes include hits, incorrect inputs and misses, but not rests. Partial mistake counters reset at each phase boundary; mistakes still reset streaks. Once a heart hit is charged, normal/gold durability rules remain unchanged. Starting tempo now 72 BPM Easy, 80 Medium, 84 Hard, 88 Expert, with the same gentle level progression and 96 BPM ceiling.

Keyboard range cycle: C4–C5 (treble), G4–G5 (treble), C3–C4 (bass), G2–G3 (bass), then repeat. Changes occur only after four complete melodies and at least 45 seconds apart, with the existing preparation pause and preview. Melodies and harmonic bridges transpose together; note hints reset on every range change. Keyboard position, computer shortcuts, staff geometry, ledger lines and samples follow the active range. The clipped black keys at window boundaries are decorative and non-interactive. Mobile keyboard side gutters are reduced to 6 px before device safe areas.

## Android Auto review (2026-10-09)

Parked Android Auto support uses a separate `CarActivity` registered with `CAR_LAUNCHER`. Regular phone launches still use `MainActivity`; the existing phone stylesheet is unchanged. The `ArcadeDisplay` native plugin identifies the car activity and loads `src/car.css` only for that activity. Screen size alone never enables car styling. An explicit browser preview is available at http://127.0.0.1:5174/?carPreview=1 while the development server is running. Native phone launches ignore this preview flag.

The car layout keeps the Arcade colors and notation, fills landscape displays, enlarges pause and menu controls, and reserves a larger keyboard area. MIDI setup is hidden on the car surface. Existing gameplay, audio timing and visibility-change pause behavior are reused. Android Auto governs parked-only availability; movement lockout and audio latency still require Desktop Head Unit or real-car acceptance on an Android 15+ phone.

Review APK: `Spino-Arcade-1.0.0-AndroidAuto-review.apk` (debug, version code 10). This is a local review build, not a new store release. It was replacement-installed on the existing SightReader emulator without clearing data, and `CarActivity` was confirmed resumed and focused. Responsive browser evidence is separate in `evidence/2026-10-09-android-auto-01`; it is not Android Auto device acceptance. The Desktop Head Unit is not installed in the local SDK. Existing automated browser tests could not complete here; gameplay and car-mode isolation checks pass.

## License

Original Spino Arcade code is licensed under GNU GPL version 3 only (GPL-3.0-only). See LICENSE. FluidR3 instrument samples retain CC BY 3.0 attribution; see assets/INSTRUMENTS-NOTICE.md. Third-party dependencies retain their respective licenses.
