# Build the Android Auto review

Install Node.js 22+, JDK 21 and Android SDK 36. Run npm ci, npm run build and npx cap sync android. Set JAVA_HOME and ANDROID_HOME, then run android/gradlew.bat assembleDebug from android/. Release signing keys are not included.

CarActivity is the parked Android Auto launcher. MainActivity retains regular phone presentation. Android Auto requires Android 15+. Projection and movement lockout remain unverified in this review build.
