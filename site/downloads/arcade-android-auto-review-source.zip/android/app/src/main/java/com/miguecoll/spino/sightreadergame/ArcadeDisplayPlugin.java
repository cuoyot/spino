// SPDX-License-Identifier: GPL-3.0-only
package com.miguecoll.spino.sightreadergame;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "ArcadeDisplay")
public class ArcadeDisplayPlugin extends Plugin {
    @PluginMethod
    public void getMode(PluginCall call) {
        JSObject result = new JSObject();
        result.put("car", getActivity() instanceof CarActivity);
        call.resolve(result);
    }
}
