// SPDX-License-Identifier: GPL-3.0-only
package com.miguecoll.spino.sightreadergame;

/** Separate launcher keeps car presentation out of regular phone launches. */
public class CarActivity extends MainActivity {}
