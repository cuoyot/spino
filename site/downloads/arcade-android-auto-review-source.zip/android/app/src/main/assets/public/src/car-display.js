// SPDX-License-Identifier: GPL-3.0-only
// Native activity identity is authoritative; viewport size never selects car mode.
export async function initializeCarDisplay() {
  const display = window.Capacitor?.Plugins?.ArcadeDisplay;
  const preview = !window.Capacitor?.isNativePlatform?.() &&
    new URLSearchParams(window.location.search).get('carPreview') === '1';
  let car = preview;
  if (display) {
    try { car = (await display.getMode()).car === true; } catch { car = false; }
  }
  if (!car) return;
  const stylesheet = document.createElement('link');
  stylesheet.rel = 'stylesheet';
  stylesheet.href = '/src/car.css';
  document.head.append(stylesheet);
  document.body.classList.add('car-display');
}
