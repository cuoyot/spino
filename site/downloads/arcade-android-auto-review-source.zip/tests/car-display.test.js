// SPDX-License-Identifier: GPL-3.0-only
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {initializeCarDisplay} from '../src/car-display.js';

test('phone launches never load car styling, including native preview URLs', async () => {
  const appended = [], classes = [];
  globalThis.document = {createElement:()=>({}),head:{append:x=>appended.push(x)},body:{classList:{add:x=>classes.push(x)}}};
  for (const Capacitor of [undefined, {isNativePlatform:()=>true,Plugins:{ArcadeDisplay:{getMode:async()=>({car:false})}}}, {isNativePlatform:()=>true,Plugins:{ArcadeDisplay:{getMode:async()=>{throw Error('Unavailable');}}}}]) {
    globalThis.window = {Capacitor, location:{search:Capacitor?'?carPreview=1':''}};
    await initializeCarDisplay();
  }
  assert.deepEqual(appended, []);
  assert.deepEqual(classes, []);
});

test('car activity and explicit browser preview load the isolated stylesheet', async () => {
  for (const Capacitor of [undefined, {isNativePlatform:()=>true,Plugins:{ArcadeDisplay:{getMode:async()=>({car:true})}}}]) {
    const appended = [], classes = [];
    globalThis.document = {createElement:()=>({}),head:{append:x=>appended.push(x)},body:{classList:{add:x=>classes.push(x)}}};
    globalThis.window = {Capacitor,location:{search:'?carPreview=1'}};
    await initializeCarDisplay();
    assert.equal(appended[0].href, '/src/car.css');
    assert.deepEqual(classes, ['car-display']);
  }
});
