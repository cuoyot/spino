// SPDX-License-Identifier: GPL-3.0-only
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {mkdir,writeFile} from 'node:fs/promises';
import {openBrowser} from './browser-helper.js';
test('responsive browser gameplay, pause and three-life results',{timeout:60000},async t=>{
 const {send,evaluate,errors}=await openBrowser(t);
 await send('Page.navigate',{url:'http://127.0.0.1:5174'});
 await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);
 await mkdir('evidence/2026-10-07-final-01',{recursive:true});
 await evaluate(`document.querySelector('#difficulty-toggle').click()`);
 assert.equal(await evaluate(`document.querySelector('#difficulty-menu').hidden`),false);
 await send('Input.dispatchKeyEvent',{type:'keyDown',key:'ArrowDown',code:'ArrowDown'});
 await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Enter',code:'Enter'});await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Enter',code:'Enter'});
 assert.equal(await evaluate(`document.querySelector('#difficulty').value`),'3');
 assert.equal(await evaluate(`document.querySelector('#difficulty-menu').hidden`),true);
 await evaluate(`document.querySelector('#difficulty-toggle').click()`);
 const picker=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/difficulty-picker.png',Buffer.from(picker.data,'base64'));
 await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape'});
 assert.equal(await evaluate(`document.querySelector('#difficulty-menu').hidden`),true);
 assert.equal(await evaluate(`document.querySelector('details #about-open')!==null`),true);
 await evaluate(`document.querySelector('#about-open').click()`);
 assert.equal(await evaluate(`document.querySelector('#about-dialog').open`),true);
 assert.match(await evaluate(`document.querySelector('#about-dialog').textContent`),/FluidR3 instruments.*Frank Wen/);
 await evaluate(`document.querySelector('#about-close').click()`);
 await evaluate(`document.querySelector('#start').click();document.querySelector('#pause').click()`);
 for(const [label,width,height] of [['phone-portrait',390,844],['phone-landscape',844,390],['tablet-portrait',768,1024],['tablet-landscape',1024,768]]){
  await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:true});
  assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true,label);
  if(label==='phone-landscape')assert.ok(await evaluate(`document.querySelector('#piano').getBoundingClientRect().height`)>120);
  const capture=await send('Page.captureScreenshot',{format:'png'});
  await writeFile(`evidence/2026-10-07-final-01/${label}.png`,Buffer.from(capture.data,'base64'));
 }
 assert.equal(await evaluate(`document.querySelector('#resume').textContent`),'Continue →');
 assert.equal(await evaluate(`getComputedStyle(document.querySelector('.language-picker')).display`),'none');
 const before=await evaluate(`document.querySelector('#lives').textContent`);
 await evaluate(`document.querySelector('[data-midi="61"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}))`);
 assert.equal(await evaluate(`document.querySelector('#lives').textContent`),before);
 await evaluate(`document.querySelector('#resume').click();window.testClock=performance.now()+600000;Object.defineProperty(performance,'now',{value:()=>window.testClock,configurable:true});`);
 await new Promise(r=>setTimeout(r,2700));
 assert.equal(await evaluate(`document.querySelector('#result').open`),true);
 assert.doesNotMatch(await evaluate(`document.querySelector('#stats').textContent`),/lives remaining/);
 await evaluate(`document.querySelector('#retry').click()`);
 assert.equal(await evaluate(`document.querySelector('#lives').getAttribute('aria-label')`),'3 lives');
 await evaluate(`document.querySelector('#pause').click();document.querySelector('#quit').click();document.querySelector('#home-button').click()`);
 assert.equal(await evaluate(`document.querySelector('#home').hidden`),false);
 await evaluate(`document.querySelector('#difficulty').value='5';document.querySelector('#difficulty').dispatchEvent(new Event('change'));document.querySelector('#language').value='es';document.querySelector('#language').dispatchEvent(new Event('change'));`);
 assert.equal(await evaluate('document.documentElement.lang'),'es');
 assert.match(await evaluate(`document.querySelector('[data-midi="60"]').textContent`),/Do/);
 assert.match(await evaluate(`document.querySelector('#difficulty-description').textContent`),/84 BPM.*negras/);
 await evaluate(`document.querySelector('#start').click();document.querySelector('#pause').click()`);
 assert.equal(await evaluate(`document.querySelector('#level').textContent`),'5');
 assert.equal(await evaluate(`document.querySelector('#resume').textContent`),'Continuar →');
 assert.match(await evaluate(`document.querySelector('#pace').textContent`),/Negras notas/);
 await evaluate(`document.querySelector('#quit').click()`);
 assert.match(await evaluate(`document.querySelector('#stats').textContent`),/Nivel 5/);
 assert.equal(await evaluate(`import('/src/audio.js').then(async audio=>{await audio.loadPiano();return audio.pianoReady();})`),true);
 await evaluate(`document.querySelector('#home-button').click();document.querySelector('#language').value='ca';document.querySelector('#language').dispatchEvent(new Event('change'));`);
 assert.equal(await evaluate('document.documentElement.lang'),'ca');
 await evaluate(`document.querySelector('#language-toggle').click()`);
 assert.equal(await evaluate(`document.querySelector('#language-menu').hidden`),false);
 assert.equal(await evaluate(`document.querySelector('[data-language="ca"]').hidden`),true);
 await evaluate(`document.querySelector('[data-language="es"]').click()`);
 assert.equal(await evaluate('document.documentElement.lang'),'es');
 assert.equal(await evaluate(`document.querySelector('#language-menu').hidden`),true);
 await evaluate(`document.querySelector('#language-toggle').click();document.querySelector('[data-language="ca"]').click()`);
 assert.equal(await evaluate(`document.querySelector('#difficulty-label').textContent`),'Dificultat inicial');
 assert.equal(await evaluate(`document.querySelector('#connect')`),null);
 assert.equal(await evaluate(`document.querySelector('#midi-game')`),null);assert.equal(await evaluate(`document.querySelectorAll('#piano .edge-key').length`),1);assert.equal(await evaluate(`document.querySelector('#piano .edge-key').hasAttribute('data-midi')`),false);
 await evaluate(`document.querySelector('#start').click()`);
 assert.equal(await evaluate(`document.querySelector('#staff .notation ellipse').getAttribute('stroke')`),'#191824');
 assert.equal(await evaluate(`getComputedStyle(document.querySelector('.staff-wrap')).backgroundColor`),'rgb(255, 254, 250)');
 await evaluate('history.back()');
 await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#pause-menu').open){clearInterval(timer);resolve();}},20);})`);
 assert.equal(await evaluate(`document.querySelector('#resume').textContent`),'Continua →');
 await evaluate(`document.querySelector('#resume').click()`);
 for(const [label,width,height] of [['phone-portrait',390,844],['phone-landscape',844,390],['tablet-portrait',768,1024],['tablet-landscape',1024,768]]){
  await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:true});
  assert.equal(await evaluate('document.documentElement.scrollWidth<=innerWidth'),true,label);
  const capture=await send('Page.captureScreenshot',{format:'png'});
  await writeFile(`evidence/2026-10-07-final-01/game-${label}.png`,Buffer.from(capture.data,'base64'));
 }
 await evaluate(`document.querySelector('#pause').click();document.querySelector('#quit').click();document.querySelector('#home-button').click()`);
 const home=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/home-ca.png',Buffer.from(home.data,'base64'));
 assert.deepEqual(errors,[]);
});

test('Catalan reward flight and gold heart are visible in the new design',{timeout:60000},async t=>{
 const {send,evaluate,errors}=await openBrowser(t);
 await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
 await send('Page.addScriptToEvaluateOnNewDocument',{source:"window.demoTime=0;Object.defineProperty(performance,'now',{value:()=>window.demoTime});localStorage.setItem('spino-game-language','ca');localStorage.setItem('spino-game-difficulty','6');"});
 await send('Page.navigate',{url:'http://127.0.0.1:5174'});
 await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);
 await evaluate(`document.querySelector('#start').click()`);
 for(let i=0;i<20;i++){
  await evaluate(`(()=>{const head=document.querySelector('#staff .notation ellipse');window.demoTime+=(Number(head.getAttribute('cx'))-190)/145*1000;})()`);
  await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');
  await evaluate(`(()=>{const head=document.querySelector('#staff .notation ellipse'),index=Math.round((220-Number(head.getAttribute('cy')))/12),midi=[60,62,64,65,67,69,71,72][index]+(head.parentElement.textContent.includes('♯')?1:head.parentElement.textContent.includes('♭')?-1:0);document.querySelector('[data-midi="'+midi+'"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));})()`);
 }
 assert.ok(await evaluate(`document.querySelector('.gold-hearts')!==null`));
 assert.ok(await evaluate(`/RATXA|COR/.test(document.querySelector('.flying-reward').textContent)`));
 assert.ok(await evaluate(`(()=>{const reward=document.querySelector('.flying-reward').getBoundingClientRect(),staff=document.querySelector('.staff-wrap').getBoundingClientRect();const style=getComputedStyle(document.querySelector('.flying-reward'));return style.backgroundColor==='rgba(0, 0, 0, 0)'&&style.borderTopWidth==='0px';})()`));
 const shot=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/reward-phone.png',Buffer.from(shot.data,'base64'));
 assert.deepEqual(errors,[]);
});

test('bass-clef transition has a visible pause and moves the keyboard down an octave',{timeout:60000},async t=>{
 const {send,evaluate,errors}=await openBrowser(t);await send('Emulation.setDeviceMetricsOverride',{width:844,height:390,deviceScaleFactor:1,mobile:true});
 await send('Page.addScriptToEvaluateOnNewDocument',{source:"window.demoTime=0;Object.defineProperty(performance,'now',{value:()=>window.demoTime});localStorage.setItem('spino-game-language','es');localStorage.setItem('spino-game-difficulty','6');"});
 await send('Page.navigate',{url:'http://127.0.0.1:5174'});await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);await evaluate(`document.querySelector('#start').click()`);
 let captured=false;
 for(let i=0;i<360;i++){
  const status=await evaluate(`(()=>{if(!document.querySelector('#clef-change').hidden)return 'change';const head=document.querySelector('#staff .notation ellipse');if(!head){demoTime+=250;return 'wait';}const x=Number(head.getAttribute('cx'));const bass=!!document.querySelector('#staff .bass-clef');const step=(bass?28:35)+Math.round(((bass?160:220)-Number(head.getAttribute('cy')))/12);window.demoNextPitch=Math.floor(step/7)*12+[0,2,4,5,7,9,11][step%7]+(head.parentElement.textContent.includes('♯')?1:head.parentElement.textContent.includes('♭')?-1:0);demoTime+=(x-190)/145*1000;return 'hit';})()`);
  if(status==='change'){if(await evaluate(`document.querySelector('#clef-change-title').textContent.includes('posición')`)){const shot=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/position-change.png',Buffer.from(shot.data,'base64'));await evaluate('demoTime+=5000');await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');assert.equal(await evaluate(`document.querySelector('#piano').dataset.start`),'67');continue;}captured=true;assert.match(await evaluate(`document.querySelector('#clef-change-title').textContent`),/Clave de fa/);const shot=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/bass-change.png',Buffer.from(shot.data,'base64'));await evaluate('demoTime+=5000');await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');break;}
  await evaluate('new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))');
  if(status==='hit')await evaluate(`document.querySelector('[data-midi="'+demoNextPitch+'"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}))`);
 }
 assert.equal(captured,true);assert.equal(await evaluate(`document.querySelector('#piano .white').dataset.midi`),'48');assert.equal(await evaluate(`document.querySelector('#result').open`),false);assert.equal(await evaluate(`document.querySelector('#staff .bass-clef')!==null`),true);const shot=await send('Page.captureScreenshot',{format:'png'});await writeFile('evidence/2026-10-07-final-01/bass-reading.png',Buffer.from(shot.data,'base64'));assert.deepEqual(errors,[]);
});


test('instrument samples load offline and the badge fits a phone', {timeout:60000}, async t=>{
 const {send,evaluate,errors}=await openBrowser(t);
 await send('Emulation.setDeviceMetricsOverride',{width:360,height:800,deviceScaleFactor:1,mobile:true});
 await send('Page.navigate',{url:'http://127.0.0.1:5174'});
 await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);
 assert.equal(await evaluate(`(async()=>{const a=await import('/src/audio.js');const {instruments}=await import('/src/instruments.js');for(const i of instruments){if(!await a.loadInstrument(i.id))return false;if(a.setInstrument(i.id)!==i.id)return false;a.playNote(60,.05);}a.setInstrument('piano');return true;})()`),true);
 await evaluate(`document.querySelector('#start').click()`);
 assert.match(await evaluate(`document.querySelector('#instrument-badge').textContent`),/Piano|piano/);
 assert.equal(await evaluate(`document.querySelector('#instrument-badge').getBoundingClientRect().right<=innerWidth`),true);
 assert.deepEqual(errors,[]);
});

test('MIDI keeps the on-screen keyboard and pressed-key animation',{timeout:60000},async t=>{const {send,evaluate}=await openBrowser(t);await send('Page.addScriptToEvaluateOnNewDocument',{source:`window.testMidiPort={};Object.defineProperty(navigator,'requestMIDIAccess',{value:async()=>({inputs:new Map([['keyboard',window.testMidiPort]])})});`});await send('Page.navigate',{url:'http://127.0.0.1:5174'});await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);await evaluate(`document.querySelector('#midi-toggle').click()`);assert.equal(await evaluate(`document.querySelector('#midi-toggle').getAttribute('aria-pressed')`),'true');await evaluate(`document.querySelector('#midi-close').click();document.querySelector('#start').click();window.testMidiPort.onmidimessage({data:[144,60,100]});`);assert.equal(await evaluate(`document.querySelector('[data-midi="60"]').classList.contains('pressed')`),true);assert.equal(await evaluate(`document.querySelector('#piano').getBoundingClientRect().height>0`),true);});

test('home fits typical phone portrait and landscape without scrolling',{timeout:60000},async t=>{const {send,evaluate}=await openBrowser(t);await send('Page.navigate',{url:'http://127.0.0.1:5174'});await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);for(const [width,height] of [[390,844],[844,390]]){await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:1,mobile:true});assert.equal(await evaluate('document.documentElement.scrollHeight<=innerHeight'),true,width+'x'+height);}});
