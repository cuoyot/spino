// SPDX-License-Identifier: GPL-3.0-only
import test from 'node:test';
import assert from 'node:assert/strict';
import {chooseInstrument,instruments,instrumentIntermission} from '../src/instruments.js';
test('instrument selection fits the register and avoids immediate repetition',()=>{for(const start of [43,48,60,67])for(const previous of instruments){for(const random of [0,.25,.5,.75,.999]){const id=chooseInstrument(start,previous.id,()=>random);assert.notEqual(id,previous.id);assert.ok(instruments.some(i=>i.id===id));if(start<60)assert.ok(['acoustic_bass','electric_bass_finger','cello','piano'].includes(id));if(start>=67)assert.ok(['violin','soprano_sax','piano'].includes(id));}}});

test('sound changes only in selected intermissions, including register changes',()=>{assert.equal(instrumentIntermission(undefined,2),false);assert.equal(instrumentIntermission({start:100},1),false);assert.equal(instrumentIntermission({start:200},2),true);assert.equal(instrumentIntermission({start:300},3),false);assert.equal(instrumentIntermission({start:400,positionTo:48},3),true);});
