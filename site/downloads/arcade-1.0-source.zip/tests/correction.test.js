// SPDX-License-Identifier: GPL-3.0-only
import {test} from 'node:test';import assert from 'node:assert/strict';import {Game} from '../src/engine.js';import {createPressGate} from '../src/midi.js';
test('a held key counts once until released',()=>{const g=createPressGate();assert.equal(g.press(60),true);assert.equal(g.press(60),false);assert.equal(g.press(60),false);g.release(60);assert.equal(g.press(60),true);});
test('correction restores half a heart, scores less, and repeat errors do not charge again',()=>{const g=new Game(()=>0);g.attempted=60;const n=g.notes[0];g.play(n.midi+1,n.at);assert.equal(g.lives,2);g.play(n.midi+2,n.at+10);assert.equal(g.lives,2);const r=g.play(n.midi,n.at+20);assert.equal(r.type,'corrected');assert.equal(g.lives,2.5);assert.equal(r.points,100);assert.equal(g.combo,0);assert.notEqual(g.notes[0].id,n.id);});
test('failed target expiry cannot charge twice',()=>{const g=new Game(()=>0);g.attempted=60;const n=g.notes[0];g.play(n.midi+1,n.at);g.advance(n.at+n.lateWindow+1);assert.equal(g.lives,2);});

test('the final error closes input permanently even during its correction window',()=>{const g=new Game(()=>0);g.attempted=60;g.lives=1;const n=g.notes[0];g.play(n.midi+1,n.at);assert.equal(g.over,true);const r=g.play(n.midi,n.at+20);assert.equal(r.type,'over');assert.equal(g.lives,0);assert.equal(g.correct,0);assert.equal(g.score,0);});
