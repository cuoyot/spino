// SPDX-License-Identifier: GPL-3.0-only
package com.miguecoll.spino.sightreadergame;

import android.os.Bundle;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ArcadeMidiPlugin.class);
        super.onCreate(savedInstanceState);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                getBridge().getWebView().evaluateJavascript(
                    "window.handleAndroidBack ? window.handleAndroidBack() : false",
                    handled -> {
                        if (!"true".equals(handled)) finish();
                    }
                );
            }
        });
    }
}
