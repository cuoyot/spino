// SPDX-License-Identifier: GPL-3.0-only
package com.miguecoll.spino.sightreadergame;
import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Build;
import android.os.ParcelUuid;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.media.midi.*;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.IOException;
@CapacitorPlugin(
    name = "ArcadeMidi",
    permissions = {
        @Permission(alias = "ble", strings = { Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "bleLegacy", strings = { Manifest.permission.ACCESS_FINE_LOCATION })
    }
)

public class ArcadeMidiPlugin extends Plugin {
 private static final ParcelUuid MIDI_SERVICE=ParcelUuid.fromString("03B80E5A-EDE8-4B33-A751-6CE34EC4C700");
 private BluetoothLeScanner scanner;private ScanCallback scanCallback;
 private MidiManager manager;private MidiDevice device;private MidiOutputPort port;private int generation=0;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private MidiManager.DeviceCallback callback;
 @Override public void load(){manager=(MidiManager)getContext().getSystemService(Context.MIDI_SERVICE);if(manager!=null){callback=new MidiManager.DeviceCallback(){@Override public void onDeviceAdded(MidiDeviceInfo info){notifyListeners("devicesChanged",new JSObject());}@Override public void onDeviceRemoved(MidiDeviceInfo info){if(device!=null&&device.getInfo().getId()==info.getId())close();notifyListeners("devicesChanged",new JSObject());}};manager.registerDeviceCallback(callback,handler);}}
 @PluginMethod public void list(PluginCall call){if(manager==null){call.reject("unsupported");return;}JSArray devices=new JSArray();for(MidiDeviceInfo info:manager.getDevices()){if(info.getOutputPortCount()==0)continue;JSObject item=new JSObject();item.put("id",String.valueOf(info.getId()));String name=info.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME);item.put("name",name==null?"MIDI keyboard":name);devices.put(item);}JSObject result=new JSObject();result.put("devices",devices);call.resolve(result);}
 @PluginMethod public void connect(PluginCall call){if(manager==null){call.reject("unsupported");return;}String id=call.getString("id");for(MidiDeviceInfo info:manager.getDevices())if(String.valueOf(info.getId()).equals(id)){close();final int request=++generation;manager.openDevice(info,opened->{if(request!=generation){try{if(opened!=null)opened.close();}catch(IOException ignored){}call.reject("Connection superseded");return;}if(opened==null){call.reject("Cannot open MIDI device");return;}device=opened;port=device.openOutputPort(0);if(port==null){close();call.reject("Cannot open MIDI port");return;}port.connect(new Receiver());keepAwake(true);call.resolve();},handler);return;}call.reject("Device disconnected");}
 @PluginMethod public void disconnect(PluginCall call){close();call.resolve();}
    @PluginMethod
    public void scanBluetooth(PluginCall call) {
        String alias = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? "ble" : "bleLegacy";
        if (getPermissionState(alias) != PermissionState.GRANTED) {
            requestPermissionForAlias(alias, call, "onBlePermission");
            return;
        }
        startScan(call);
    }

    @PermissionCallback
    private void onBlePermission(PluginCall call) {
        String alias = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? "ble" : "bleLegacy";
        if (getPermissionState(alias) == PermissionState.GRANTED) startScan(call);
        else call.reject("Bluetooth permission denied");
    }

    @SuppressLint("MissingPermission")
    private void startScan(PluginCall call) {
        BluetoothAdapter adapter = adapter();
        if (adapter == null || !adapter.isEnabled()) {
            call.reject("Bluetooth is off");
            return;
        }
        stopScan();
        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            call.reject("Bluetooth LE is unavailable");
            return;
        }
        scanCallback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice d = result.getDevice();
                JSObject ev = new JSObject();
                ev.put("address", d.getAddress());
                String name = result.getScanRecord() != null ? result.getScanRecord().getDeviceName() : null;
                ev.put("name", name != null ? name : d.getName());
                notifyListeners("bleDevice", ev);
            }
        };
        ScanFilter filter = new ScanFilter.Builder().setServiceUuid(MIDI_SERVICE).build();
        ScanSettings settings = new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build();
        scanner.startScan(Collections.singletonList(filter), settings, scanCallback);
        int seconds = call.getInt("seconds", 10);
        handler.postDelayed(this::stopScan, seconds * 1000L);
        call.resolve();
    }

    @SuppressLint("MissingPermission")
    private void stopScan() {
        if (scanner != null && scanCallback != null) {
            try {
                scanner.stopScan(scanCallback);
            } catch (Exception ignored) {}
        }
        scanCallback = null;
    }

    @SuppressLint("MissingPermission")
    @PluginMethod
    public void connectBluetooth(PluginCall call) {
        String address = call.getString("address");
        BluetoothAdapter adapter = adapter();
        if (address == null || adapter == null || manager == null) {
            call.reject("Bluetooth MIDI unavailable");
            return;
        }
        stopScan();
        BluetoothDevice device = adapter.getRemoteDevice(address);
        manager.openBluetoothDevice(
            device,
            d -> {
                if (d == null) {
                    call.reject("Could not open " + address);
                    return;
                }
                attachBluetooth(d);
                JSObject ret = new JSObject();
                ret.put("devices", new JSArray());
                call.resolve(ret);
            },
            handler
        );
    }

    private BluetoothAdapter adapter() {
        BluetoothManager bm = (BluetoothManager) getContext().getSystemService(Context.BLUETOOTH_SERVICE);
        return bm != null ? bm.getAdapter() : null;
    }


 private void keepAwake(boolean active){getActivity().runOnUiThread(()->{if(active)getActivity().getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getActivity().getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);});}
 private void attachBluetooth(MidiDevice opened){close();device=opened;port=device.openOutputPort(0);if(port!=null){port.connect(new Receiver());keepAwake(true);notifyListeners("devicesChanged",new JSObject());}else close();}
 private void close(){stopScan();keepAwake(false);generation++;try{if(port!=null)port.close();if(device!=null)device.close();}catch(IOException ignored){}port=null;device=null;}
 private class Receiver extends MidiReceiver{private int status=0,count=0,note=0;@Override public void onSend(byte[] data,int offset,int length,long timestamp){for(int i=offset;i<offset+length;i++){int b=data[i]&255;if(b>=248)continue;if(b>=128){status=b<240?b:0;count=0;continue;}if(status==0)continue;int kind=status&240;if(kind==192||kind==208)continue;if(count++==0){note=b;}else{count=0;if(kind==128||(kind==144&&b==0)){JSObject release=new JSObject();release.put("note",note);notifyListeners("noteOff",release);}if(kind==144&&b>0){JSObject event=new JSObject();event.put("note",note);event.put("velocity",b);notifyListeners("noteOn",event);}}}}}
 @Override protected void handleOnDestroy(){close();if(manager!=null&&callback!=null)manager.unregisterDeviceCallback(callback);}
}
