// SPDX-License-Identifier: GPL-3.0-only
import {mkdir,writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';
import {openBrowser} from './record-browser-helper.js';
const out='evidence/2026-10-07-skilled-demo';
await mkdir(`${out}/frames`,{recursive:true});
const cleanup=[];
const {send,evaluate,errors}=await openBrowser({after:fn=>cleanup.push(fn)});
try{
 await send('Emulation.setDeviceMetricsOverride',{width:1024,height:768,deviceScaleFactor:1,mobile:false});
 await send('Page.addScriptToEvaluateOnNewDocument',{source:`
 localStorage.setItem('spino-game-language','en');localStorage.setItem('spino-game-difficulty','5');
 window.demoAudio=[];
 const original=AudioNode.prototype.connect;
 AudioNode.prototype.connect=function(destination,...args){
  if(destination===this.context.destination){
   if(!window.demoDestination){window.demoDestination=this.context.createMediaStreamDestination();window.demoRecorder=new MediaRecorder(window.demoDestination.stream);demoRecorder.ondataavailable=e=>demoAudio.push(e.data);demoRecorder.start();}
   original.call(this,window.demoDestination);
  }return original.call(this,destination,...args);
 };`});
 await send('Page.navigate',{url:'http://127.0.0.1:5174/'});
 await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);
 await evaluate(`document.querySelector('#start').click();const banner=document.createElement('div');banner.id='demo-banner';banner.style='position:fixed;bottom:8px;left:16px;color:#ffd36f;background:#0a1021e6;padding:6px 12px;border-radius:8px;font:13px system-ui;z-index:10';banner.textContent='SIMULATED PLAYER · Hard start · real-time browser gameplay';document.body.append(banner);window.demoHits=0;window.demoMistake=false;window.demoLog=[];`);
 const began=performance.now();const timestamps=[];
 for(let i=0;i<600;i++){
  await evaluate(`(()=>{const head=document.querySelector('#staff g ellipse');if(!head)return;const x=Number(head.getAttribute('cx'));if(x<181||x>197)return;const y=Number(head.getAttribute('cy'));const position=Math.round((220-y)/12);const pitches=[60,62,64,65,67,69,71,72];const sharp=head.parentElement.textContent.includes('♯');let midi=pitches[position]+(sharp?1:0);if(!demoMistake){midi=59;demoMistake=true;}else demoHits++;document.querySelector('[data-midi="'+(midi===59?61:midi)+'"]').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));demoLog.push({hit:demoHits,score:document.querySelector('#score').textContent,level:document.querySelector('#level').textContent,lives:document.querySelector('#lives').getAttribute('aria-label'),feedback:document.querySelector('#feedback').textContent});})()`);
  timestamps.push((performance.now()-began)/1000);const shot=await send('Page.captureScreenshot',{format:'jpeg',quality:85});
  await writeFile(`${out}/frames/${String(i).padStart(5,'0')}.jpg`,Buffer.from(shot.data,'base64'));
  const delay=began+(i+1)*1000/15-performance.now();if(delay>0)await new Promise(r=>setTimeout(r,delay));
  if(i%150===0)console.log(`Recorded ${Math.round(i/15)} seconds`);
 }
 const audio=await evaluate(`new Promise(resolve=>{demoRecorder.onstop=async()=>{const bytes=new Uint8Array(await new Blob(demoAudio).arrayBuffer());let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);resolve(btoa(binary));};demoRecorder.stop();})`);
 await writeFile(`${out}/piano.webm`,Buffer.from(audio,'base64'));
 const duration=(performance.now()-began)/1000;await writeFile(`${out}/frames.txt`,timestamps.map((time,i)=>`file 'frames/${String(i).padStart(5,'0')}.jpg'\nduration ${i<timestamps.length-1?timestamps[i+1]-time:duration-time}`).join('\n')+`\nfile 'frames/00599.jpg'\n`);
 const log=await evaluate('demoLog');await writeFile(`${out}/run.json`,JSON.stringify({kind:'Simulated skilled input on actual browser build',startingLevel:5,capturedAt:'2026-10-07',durationSeconds:duration,log,errors},null,2));
 console.log(JSON.stringify({hits:log.length,final:log.at(-1),errors}));
}finally{for(const fn of cleanup)await fn();}
