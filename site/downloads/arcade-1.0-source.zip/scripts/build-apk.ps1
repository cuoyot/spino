$ErrorActionPreference = 'Stop'
$toolchain = Join-Path $env:USERPROFILE 'Android'
$env:JAVA_HOME = Join-Path $toolchain 'jdk'
$env:ANDROID_HOME = Join-Path $toolchain 'sdk'
$env:JAVA_TOOL_OPTIONS = "-Djdk.net.unixdomain.tmpdir=$toolchain\tmp"
Set-Location (Split-Path $PSScriptRoot)
npm run build
if ($LASTEXITCODE -ne 0) { throw 'Web build failed.' }
npx cap sync android
if ($LASTEXITCODE -ne 0) { throw 'Android sync failed.' }
Push-Location android
try {
    .\gradlew.bat assembleDebug bundleRelease --console=plain
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed.' }
} finally { Pop-Location }
Copy-Item -LiteralPath android\app\build\outputs\apk\debug\app-debug.apk -Destination Spino-Arcade-1.0.0.apk -Force
Write-Host "APK ready: $(Resolve-Path Spino-Arcade-1.0.0.apk)"

New-Item -ItemType Directory -Force -Path publishing/1.0.0 | Out-Null
Copy-Item android/app/build/outputs/bundle/release/app-release.aab publishing/1.0.0/Spino-Arcade-1.0.0.aab -Force
Write-Host 'Release bundle copied. Without SPINO_KEYSTORE environment configuration, the AAB is unsigned.'
