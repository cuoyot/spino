// SPDX-License-Identifier: GPL-3.0-only
import {mkdir,cp,readFile,writeFile} from 'node:fs/promises';
await mkdir('dist',{recursive:true});
for(const path of ['index.html','src','assets'])await cp(path,`dist/${path}`,{recursive:true});
const pkg=JSON.parse(await readFile('package.json','utf8'));
await writeFile('dist/build-info.json',JSON.stringify({name:pkg.name,version:pkg.version,builtAt:new Date().toISOString()},null,2));
console.log(`Web build ready: ${pkg.version}`);
