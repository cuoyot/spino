// SPDX-License-Identifier: GPL-3.0-only
import {test} from 'node:test';
import {mkdir,writeFile} from 'node:fs/promises';
import {openBrowser} from '../tests/browser-helper.js';
test('capture publication artwork and actual responsive screens',{timeout:60000},async t=>{
 const {send,evaluate}=await openBrowser(t);const folder='publishing/0.9.0/graphics';
 async function size(width,height,scale=1){await send('Emulation.setDeviceMetricsOverride',{width,height,deviceScaleFactor:scale,mobile:false});}
 async function shot(name){const r=await send('Page.captureScreenshot',{format:'png'});await writeFile(folder+'/'+name+'.png',Buffer.from(r.data,'base64'));}
 await size(1024,500);await send('Page.navigate',{url:'http://127.0.0.1:5174/publishing/0.9.0/graphics/source.html'});await new Promise(r=>setTimeout(r,400));await shot('feature-en');
 for(const [lang,text] of [['es','Lee. Toca.<br>Sigue el ritmo.'],['ca','Llegeix. Toca.<br>Segueix el ritme.']]){await evaluate(`document.querySelector('p').innerHTML=${JSON.stringify(text)}`);await shot('feature-'+lang);}
 await size(512,512);await evaluate(`document.body.innerHTML='<svg width="512" height="512" viewBox="0 0 108 108"><rect width="108" height="108" fill="#23213c"/><path d="M62 26v43c-18-9-30 3-24 13 7 10 24 3 24-8V39l21-5V23z" fill="#ff997b"/><path d="m29 23 3 7 8 1-6 5 2 8-7-4-7 4 2-8-6-5 8-1z" fill="#ffdf69"/></svg>'`);await shot('icon-512');
 for(const lang of ['en','es','ca']){await size(540,960,2);await send('Page.navigate',{url:'http://127.0.0.1:5174/'});await evaluate(`new Promise(resolve=>{const timer=setInterval(()=>{if(document.querySelector('#start')?.onclick){clearInterval(timer);resolve();}},20);})`);await evaluate(`document.querySelector('[data-language="${lang}"]')?.click();document.querySelector('#language').value='${lang}';document.querySelector('#language').dispatchEvent(new Event('change'));`);await shot('phone-home-'+lang);await evaluate(`document.querySelector('#start').click()`);await new Promise(r=>setTimeout(r,3000));await shot('phone-game-'+lang);await size(960,540,2);await shot('landscape-game-'+lang);}
});