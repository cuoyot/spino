# Building Spino Arcade 1.0

Install Node.js 22, Java 21 and Android SDK with API 36. Run npm ci, npm run build and npx cap sync android, then gradlew assembleDebug or bundleRelease from android/. Configure signing via SPINO_KEYSTORE, SPINO_STORE_PASSWORD, SPINO_KEY_ALIAS and SPINO_KEY_PASSWORD. Release signing secrets are not included.
